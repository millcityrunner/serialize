from tests.unit import Suite


def test_full_run():
    ts = Suite()
